import math

def calculate_solar_prediction(environmental_data):
    """
    Calculate solar energy potential from environmental data.
    """

    solar = environmental_data.get("solarIrradiance", 0) or 0
    temperature = environmental_data.get("temperature", 25) or 25
    cloud_cover = environmental_data.get("cloudCover", 0) or 0

    # Peak Sun Hours (approximation)
    peak_sun_hours = round(solar, 2)

    # Panel efficiency (18%)
    panel_efficiency = 0.18

    # System capacity (1 kW reference system)
    system_capacity = 1

    # Daily energy generation
    daily_energy = round(
        peak_sun_hours * system_capacity * panel_efficiency,
        2
    )

    # Annual energy generation
    annual_energy = round(
        daily_energy * 365,
        2
    )

    # Temperature loss
    temperature_loss = max(0, (temperature - 25) * 0.004)

    performance_ratio = round(
        0.80 - temperature_loss,
        2
    )

    if performance_ratio < 0:
        performance_ratio = 0

    capacity_factor = round(
        (annual_energy / 8760) * 100,
        2
    )

    # Solar potential
    if solar >= 6:
        potential = "Excellent"

    elif solar >= 5:
        potential = "High"

    elif solar >= 4:
        potential = "Moderate"

    else:
        potential = "Low"

    return {
        "annualIrradiance": solar,
        "peakSunHours": peak_sun_hours,
        "dailyEnergyOutput": daily_energy,
        "annualEnergyOutput": annual_energy,
        "capacityFactor": capacity_factor,
        "performanceRatio": performance_ratio,
        "solarPotential": potential,
        "panelEfficiency": panel_efficiency * 100
    }